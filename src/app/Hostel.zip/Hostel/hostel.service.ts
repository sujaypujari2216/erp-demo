import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";

@Injectable({
  // tslint:disable-next-line: quotemark
  providedIn: "root",
})
export class HostelService {
  // tslint:disable-next-line: quotemark
  private REST_API_SERVER = "http://yamistha.cloudjiffy.net/hostel";

  constructor(private httpClient: HttpClient) {}
  public sendGetRequest() {
    return this.httpClient.get(this.REST_API_SERVER);
  }
}
